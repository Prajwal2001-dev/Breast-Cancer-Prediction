import streamlit as st
import pandas as pd
import pickle
import plotly.express as px

# Set up the page
st.set_page_config(page_title="Fetal Health Prediction App", layout="wide")
st.title("👶 **Fetal Health Prediction App**")

st.markdown(
    """
    Welcome to the **Fetal Health Prediction App**, an interactive tool for analyzing fetal health based on cardiotocogram features.  
    Enter feature values below to predict fetal health status, or upload a dataset for bulk prediction.
    """
)
st.markdown("---")

# Load the model
@st.cache_data
def load_model():
    with open("save_model/fetal_health_model.pkl", "rb") as file:
        model = pickle.load(file)
    return model

model = load_model()

# Feature Descriptions
st.write("## 📚 About CTG Features")
st.markdown("These features are derived from the cardiotocogram (CTG) and are used for fetal health prediction:")

st.table(
    pd.DataFrame({
        "Feature": [
            "baseline_value", "accelerations", "uterine_contractions", "light_decelerations",
            "prolongued_decelerations", "abnormal_short_term_variability",
            "mean_value_of_short_term_variability", "percentage_of_time_with_abnormal_long_term_variability",
            "mean_value_of_long_term_variability", "histogram_width", "histogram_min", "histogram_max",
            "histogram_number_of_peaks", "histogram_mean", "histogram_variance", "histogram_tendency"
        ],
        "Description": [
            "Baseline fetal heart rate (FHR).",
            "FHR accelerations per second.",
            "Uterine contractions per second.",
            "Light decelerations per second.",
            "Prolonged decelerations per second.",
            "Number of abnormal short term variability episodes.",
            "Mean of short term variability.",
            "Percentage of time with abnormal long term variability.",
            "Mean of long term variability.",
            "Width of the histogram of FHR.",
            "Minimum value of histogram.",
            "Maximum value of histogram.",
            "Number of peaks in the histogram.",
            "Mean value of histogram.",
            "Variance of histogram values.",
            "Tendency of histogram (increasing/decreasing)."
        ]
    })
)

st.markdown("---")
st.write("## 🍼 **Enter CTG Feature Values**")

# Form for input
with st.form("ctg_form"):
    cols = st.columns(2)

    with cols[0]:
        baseline_value = st.number_input("Baseline FHR (bpm):", 80.0, 200.0, 120.0)
        accelerations = st.number_input("Accelerations (/sec):", 0.0, 1.0, 0.02)
        uterine_contractions = st.number_input("Uterine Contractions (/sec):", 0.0, 1.0, 0.005)
        light_decelerations = st.number_input("Light Decelerations (/sec):", 0.0, 1.0, 0.01)
        prolongued_decelerations = st.number_input("Prolonged Decelerations (/sec):", 0.0, 1.0, 0.001)
        abnormal_short_term_variability = st.number_input("Abnormal Short Term Variability (count):", 0, 10, 0)
        mean_stv = st.number_input("Mean Short Term Variability:", 0.0, 10.0, 0.5)
        abnormal_ltv_pct = st.number_input("Abnormal Long Term Variability (%):", 0.0, 100.0, 15.0)

    with cols[1]:
        mean_ltv = st.number_input("Mean Long Term Variability:", 0.0, 10.0, 2.0)
        histogram_width = st.number_input("Histogram Width:", 0.0, 50.0, 10.0)
        histogram_min = st.number_input("Histogram Min:", 50.0, 150.0, 60.0)
        histogram_max = st.number_input("Histogram Max:", 100.0, 200.0, 130.0)
        histogram_peaks = st.number_input("Number of Histogram Peaks:", 0, 20, 5)
        histogram_mean = st.number_input("Histogram Mean:", 80.0, 180.0, 120.0)
        histogram_variance = st.number_input("Histogram Variance:", 0.0, 100.0, 10.0)
        histogram_tendency = st.number_input("Histogram Tendency:", -10, 10, 0)

    submitted = st.form_submit_button("🚀 Predict Fetal Health")

    if submitted:
        input_data = pd.DataFrame([{
            'baseline_value': baseline_value,
            'accelerations': accelerations,
            'uterine_contractions': uterine_contractions,
            'light_decelerations': light_decelerations,
            'prolongued_decelerations': prolongued_decelerations,
            'abnormal_short_term_variability': abnormal_short_term_variability,
            'mean_value_of_short_term_variability': mean_stv,
            'percentage_of_time_with_abnormal_long_term_variability': abnormal_ltv_pct,
            'mean_value_of_long_term_variability': mean_ltv,
            'histogram_width': histogram_width,
            'histogram_min': histogram_min,
            'histogram_max': histogram_max,
            'histogram_number_of_peaks': histogram_peaks,
            'histogram_mean': histogram_mean,
            'histogram_variance': histogram_variance,
            'histogram_tendency': histogram_tendency
        }])

        with st.spinner("Analyzing CTG data..."):
            prediction = model.predict(input_data)[0]
            probabilities = model.predict_proba(input_data)[0]

        health_status = {
            1: "Normal",
            2: "Suspect",
            3: "Pathological"
        }

        st.markdown("### **Prediction Result**")
        if prediction == 1:
            st.success(f"Fetal health is predicted to be **{health_status[prediction]}**.")
        elif prediction == 2:
            st.warning(f"Fetal health is predicted to be **{health_status[prediction]}**.")
        else:
            st.error(f"Fetal health is predicted to be **{health_status[prediction]}**.")

        st.markdown("### **Class Probabilities**")
        st.write({
            "Normal": f"{probabilities[0]*100:.2f}%",
            "Suspect": f"{probabilities[1]*100:.2f}%",
            "Pathological": f"{probabilities[2]*100:.2f}%"
        })

        st.markdown("### **Input Summary**")
        st.dataframe(input_data)

# Footer
st.markdown("---")
st.write("Developed with ❤️ using Streamlit")
st.markdown("""
**Disclaimer:** This tool is for educational and demonstration purposes only.  
Always consult medical professionals for diagnosis and treatment.
""")
